(function () {
  var P = {
    grid: '<rect x="3" y="3" width="7" height="7" rx="2"/><rect x="14" y="3" width="7" height="7" rx="2"/><rect x="3" y="14" width="7" height="7" rx="2"/><rect x="14" y="14" width="7" height="7" rx="2"/>',
    box: '<path d="m21 8-9 5-9-5"/><path d="M3 8l9-5 9 5v8l-9 5-9-5Z"/><path d="M12 13v8"/>',
    cart: '<circle cx="9" cy="20" r="1"/><circle cx="19" cy="20" r="1"/><path d="M3 4h2l2.4 10.2a2 2 0 0 0 2 1.6h7.9a2 2 0 0 0 2-1.6L21 8H6"/>',
    wallet: '<path d="M4 6.5h14a2 2 0 0 1 2 2v10H5a3 3 0 0 1-3-3v-10a3 3 0 0 1 3-3h12"/><path d="M20 10h-5a2 2 0 0 0 0 4h5"/>',
    chart: '<path d="M4 20V10"/><path d="M10 20V4"/><path d="M16 20v-7"/><path d="M22 20H2"/>',
    settings: '<circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.7 1.7 0 0 0 .3 1.9l.1.1-2.8 2.8-.1-.1a1.7 1.7 0 0 0-1.9-.3 1.7 1.7 0 0 0-1 1.6v.2h-4V21a1.7 1.7 0 0 0-1-1.6 1.7 1.7 0 0 0-1.9.3l-.1.1L4.2 17l.1-.1a1.7 1.7 0 0 0 .3-1.9A1.7 1.7 0 0 0 3 14H2.8v-4H3a1.7 1.7 0 0 0 1.6-1 1.7 1.7 0 0 0-.3-1.9L4.2 7 7 4.2l.1.1A1.7 1.7 0 0 0 9 4.6a1.7 1.7 0 0 0 1-1.6v-.2h4V3a1.7 1.7 0 0 0 1 1.6 1.7 1.7 0 0 0 1.9-.3l.1-.1L19.8 7l-.1.1a1.7 1.7 0 0 0-.3 1.9 1.7 1.7 0 0 0 1.6 1h.2v4H21a1.7 1.7 0 0 0-1.6 1Z"/>',
    search: '<circle cx="11" cy="11" r="7"/><path d="m20 20-4-4"/>',
    bell: '<path d="M18 8a6 6 0 0 0-12 0c0 7-3 7-3 9h18c0-2-3-2-3-9"/><path d="M10 21h4"/>',
    plus: '<path d="M12 5v14M5 12h14"/>',
    arrowUp: '<path d="m18 15-6-6-6 6"/>',
    arrowDown: '<path d="m6 9 6 6 6-6"/>',
    alert: '<path d="M12 3 2.7 20h18.6Z"/><path d="M12 9v4M12 17h.01"/>',
    check: '<path d="m5 12 4 4L19 6"/>',
    x: '<path d="m6 6 12 12M18 6 6 18"/>',
    chevron: '<path d="m9 18 6-6-6-6"/>',
    download: '<path d="M12 3v12m0 0 5-5m-5 5-5-5M5 21h14"/>',
    menu: '<path d="M4 7h16M4 12h16M4 17h16"/>'
  };
  var ic = function (n, s) {
    s = s || 20;
    return '<svg width="' + s + '" height="' + s + '" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">' + P[n] + '</svg>';
  };

  var products = [
    { name: "Controle DualSense PS5", sku: "GAM-0142", category: "Games", stock: 12, minimum: 5, price: 449.9, status: "Normal" },
    { name: "Cabo USB-C 2m", sku: "ACE-0089", category: "Acessórios", stock: 3, minimum: 8, price: 39.9, status: "Estoque baixo" },
    { name: "Película iPhone 15", sku: "CEL-0201", category: "Smartphones", stock: 2, minimum: 10, price: 29.9, status: "Crítico" },
    { name: "Headset Gamer H200", sku: "GAM-0118", category: "Games", stock: 18, minimum: 6, price: 189.9, status: "Normal" },
    { name: "Câmbio Shimano TZ500", sku: "BIK-0054", category: "Bicicletas", stock: 7, minimum: 4, price: 84.9, status: "Normal" }
  ];
  var sales = [
    { time: "14:32", item: "Controle DualSense PS5", channel: "Loja física", value: 449.9, method: "Pix" },
    { time: "13:48", item: "Cabo USB-C 2m", channel: "Mercado Livre", value: 79.8, method: "Marketplace" },
    { time: "12:15", item: "Impressão colorida", channel: "Loja física", value: 24.0, method: "Dinheiro" },
    { time: "11:03", item: "Headset Gamer H200", channel: "Shopee", value: 189.9, method: "Marketplace" }
  ];
  var nav = [["Visão geral", "grid"], ["Estoque", "box"], ["Vendas", "cart"], ["Caixa", "wallet"], ["Relatórios", "chart"]];
  var money = function (v) { return v.toLocaleString("pt-BR", { style: "currency", currency: settings && settings.currency ? settings.currency : "BRL" }); };
  var saved = {};
  try { saved = JSON.parse(localStorage.getItem("zick-gestao") || "{}"); } catch (err) { saved = {}; }
  var account = Object.assign({ name: "André Teixeira", email: "andre@zickgestao.com.br", role: "Administrador" }, saved.account || {});
  var settings = Object.assign({ company: "Zick Gestão", email: "andre@zickgestao.com.br", currency: "BRL", notifications: true, lowStock: true, compact: false }, saved.settings || {});
  if (Array.isArray(saved.products) && saved.products.length) products = saved.products;
  if (Array.isArray(saved.sales) && saved.sales.length) sales = saved.sales;
  var S = { active: "Visão geral", query: "", category: "Todas", modal: null, menu: false, prod: products[0].name, qty: 1, target: null, cashOpen: true };
  var root = document.getElementById("root");
  var toastT;

  function updateStatus(p) {
    p.status = p.stock <= p.minimum / 2 ? "Crítico" : p.stock < p.minimum ? "Estoque baixo" : "Normal";
  }

  function parseMoney(value) {
    return Number(String(value || "").replace(/[^0-9,.-]/g, "").replace(/\./g, "").replace(",", ".")) || 0;
  }

  function downloadCsv(filename, rowsData) {
    var csv = rowsData.map(function (row) { return row.map(function (cell) { return '"' + String(cell).replace(/"/g, '""') + '"'; }).join(";"); }).join("\n");
    var blob = new Blob(["\ufeff" + csv], { type: "text/csv;charset=utf-8;" });
    var link = document.createElement("a"); link.href = URL.createObjectURL(blob); link.download = filename; link.click();
    setTimeout(function () { URL.revokeObjectURL(link.href); }, 500);
  }

  function toast(msg) {
    var t = document.getElementById("toast");
    if (!t) { t = document.createElement("div"); t.id = "toast"; t.className = "toast"; document.body.appendChild(t); }
    t.innerHTML = "<span>" + ic("check", 16) + "</span>" + msg;
    t.style.display = "flex";
    clearTimeout(toastT);
    toastT = setTimeout(function () { t.style.display = "none"; }, 2800);
  }

  var metric = function (title, value, trend, cap, icon, tone, down, alert) {
    return '<div class="metric-card"><div class="metric-icon ' + tone + '">' + ic(icon) + '</div><div class="metric-title">' + title + '<span>•••</span></div><strong class="metric-value">' + value + '</strong><div class="metric-caption">' +
      (trend ? '<b class="' + (down ? "down" : "") + '">' + ic(down ? "arrowDown" : "arrowUp", 12) + trend + "</b>" : "") +
      '<span class="' + (alert ? "alert-text" : "") + '">' + cap + "</span></div></div>";
  };
  var panelHead = function (t, s, a) {
    var action = a === "Ver todas" ? "all-sales" : a === "Ver extrato completo" ? "statement" : a === "Últimos 7 dias" ? "period" : "";
    return '<div class="panel-header"><div><h3>' + t + "</h3><p>" + s + "</p></div>" + (a ? '<button data-a="panel" data-panel="' + action + '">' + a + ic("chevron", 14) + "</button>" : "") + "</div>";
  };
  var legend = function (c, n, v) { return '<div class="legend-row"><span style="background:' + c + '"></span><p>' + n + "</p><strong>" + v + "</strong></div>"; };

  function chart() {
    var vals = [36, 52, 41, 72, 60, 84, 73], d = "M0 120 C60 100 60 80 116 88 S180 115 233 102 S300 43 350 50 S420 82 466 68 S535 20 583 28 S650 60 700 45";
    var dots = vals.map(function (v, i) { return '<circle cx="' + (i * 700) / 6 + '" cy="' + (180 - v * 1.8) + '" r="4"></circle>'; }).join("");
    return '<div class="chart"><div class="chart-y"><span>R$ 2k</span><span>R$ 1,5k</span><span>R$ 1k</span><span>R$ 500</span><span>R$ 0</span></div><div class="chart-area"><div class="grid-lines"><i></i><i></i><i></i><i></i><i></i></div>' +
      '<svg viewBox="0 0 700 180" preserveAspectRatio="none"><defs><linearGradient id="area" x1="0" x2="0" y1="0" y2="1"><stop offset="0%" stop-color="#315bea" stop-opacity=".22"/><stop offset="100%" stop-color="#315bea" stop-opacity="0"/></linearGradient></defs>' +
      '<path class="area" d="' + d + ' L700 180 L0 180Z"></path><path class="line" d="' + d + '"></path>' + dots + "</svg>" +
      '<div class="chart-days">' + ["Seg", "Ter", "Qua", "Qui", "Sex", "Sáb", "Dom"].map(function (x) { return "<span>" + x + "</span>"; }).join("") + "</div></div></div>";
  }

  function rows() {
    var q = S.query.toLowerCase();
    return products.filter(function (p) { return (S.category === "Todas" || p.category === S.category) && (p.name.toLowerCase().includes(q) || p.sku.toLowerCase().includes(q)); }).map(function (p) {
      var cls = p.status === "Normal" ? "ok" : p.status === "Crítico" ? "critical" : "low";
      return '<tr><td><div class="product-cell"><span>' + p.name.slice(0, 2).toUpperCase() + "</span><div><strong>" + p.name + "</strong><small>" + p.sku + "</small></div></div></td><td>" + p.category +
        "</td><td><strong>" + p.stock + "</strong> <small>/ mín. " + p.minimum + "</small></td><td>" + money(p.price) + '</td><td><span class="status ' + cls + '">' + p.status +
        '</span></td><td><button class="row-action" data-a="move" data-n="' + p.name + '">•••</button></td></tr>';
    }).join("");
  }

  function inventory() {
    var categories = ["Todas"].concat(products.map(function (p) { return p.category; }).filter(function (x, i, a) { return a.indexOf(x) === i; }));
    var options = categories.map(function (c) { return '<option' + (S.category === c ? ' selected' : '') + '>' + c + '</option>'; }).join("");
    return '<div class="panel inventory-panel"><div class="inventory-toolbar"><div class="table-search">' + ic("search", 18) + '<input id="q" value="' + S.query + '" placeholder="Buscar produto ou SKU..."></div><label class="category-select"><span>Categoria</span><select id="categoryFilter">' + options + '</select></label><button class="primary" data-a="addprod">' + ic("plus", 17) + ' Adicionar produto</button></div><div class="table-wrap"><table><thead><tr><th>PRODUTO</th><th>CATEGORIA</th><th>ESTOQUE</th><th>PREÇO</th><th>STATUS</th><th></th></tr></thead><tbody id="tbody">' + rows() + "</tbody></table></div></div>";
  }

  function cashView() {
    var open = S.cashOpen;
    return '<div class="cash-view"><div class="panel cash-hero"><div><span class="cash-open"><i></i> CAIXA ' + (open ? 'ABERTO' : 'FECHADO') + '</span><h2>' + (open ? 'R$ 2.265,50' : 'R$ 0,00') + '</h2><p>' + (open ? 'Saldo esperado neste momento' : 'Abra o caixa para registrar novas movimentações') + '</p></div><button class="primary" data-a="' + (open ? 'cash' : 'open-cash') + '">' + (open ? 'Fechar caixa agora' : 'Abrir caixa') + '</button></div>' +
      '<div class="metrics">' + metric("Saldo inicial", "R$ 500,00", "", "aberto às 08:02", "wallet", "blue") + metric("Total de entradas", "R$ 1.847,90", "+12,5%", "comparado a ontem", "arrowUp", "green") + metric("Total de saídas", "R$ 82,40", "", "3 retiradas registradas", "arrowDown", "orange") + "</div>" +
      '<div class="panel">' + panelHead("Movimentações do caixa", "Registros de hoje, 30 de setembro", "Ver extrato completo") + '<div class="movement-list">' + sales.map(function (x) { return '<div><span class="sale-icon">' + ic("arrowUp", 16) + "</span><p><strong>" + x.item + "</strong><small>" + x.time + " · " + x.method + '</small></p><strong class="positive">+ ' + money(x.value) + "</strong></div>"; }).join("") + "</div></div></div>";
  }

  function soon() {
    var v = S.active === "Vendas";
    return '<div class="panel coming-soon"><div class="metric-icon blue">' + ic(v ? "cart" : "chart", 28) + '</div><span class="eyebrow">MÓDULO INTEGRADO</span><h2>' + S.active + "</h2><p>" +
      (v ? "Registre e acompanhe vendas de todos os seus canais em um só lugar." : "Visualize resultados e exporte dados para suas planilhas.") + '</p><button class="primary" data-a="' + (v ? "sale" : "export2") + '">' + (v ? "Registrar nova venda" : "Exportar relatório") + ic("chevron", 16) + "</button></div>";
  }

  function persist() {
    localStorage.setItem("zick-gestao", JSON.stringify({ account: account, settings: settings, products: products, sales: sales }));
  }

  function settingsView() {
    return '<div class="settings-layout"><div class="panel settings-intro"><div class="metric-icon blue">' + ic("settings", 24) + '</div><h2>Preferências do sistema</h2><p>Personalize o funcionamento do Zick Gestão para a rotina da sua empresa.</p><div class="settings-note"><strong>Seus dados ficam seguros</strong><span>As alterações são salvas neste navegador.</span></div></div>' +
      '<form class="panel settings-form" id="settingsForm"><div class="panel-header"><div><h3>Configurações gerais</h3><p>Defina as informações e avisos do sistema.</p></div><button class="primary" type="submit">Salvar alterações</button></div>' +
      '<div class="settings-section"><span class="settings-label">Dados da empresa</span><div class="form-row"><label>Nome da empresa<input name="company" value="' + settings.company + '" required></label><label>Moeda padrão<select name="currency"><option value="BRL"' + (settings.currency === "BRL" ? " selected" : "") + '>Real brasileiro (R$)</option><option value="USD"' + (settings.currency === "USD" ? " selected" : "") + '>Dólar americano ($)</option></select></label></div><label>E-mail para receber relatórios<input name="email" type="email" value="' + settings.email + '" required></label></div>' +
      '<div class="settings-section"><span class="settings-label">Notificações</span>' + settingToggle("notifications", "Notificações do sistema", "Receba avisos sobre atividades importantes.", settings.notifications) + settingToggle("lowStock", "Alertas de estoque baixo", "Avise quando um produto atingir o estoque mínimo.", settings.lowStock) + '</div>' +
      '<div class="settings-section"><span class="settings-label">Visualização</span>' + settingToggle("compact", "Modo compacto", "Reduza o espaçamento das listas para ver mais informações.", settings.compact) + '</div></form></div>';
  }

  function settingToggle(name, title, description, checked) {
    return '<label class="setting-row"><span><strong>' + title + '</strong><small>' + description + '</small></span><input type="checkbox" name="' + name + '"' + (checked ? " checked" : "") + '><i class="toggle"></i></label>';
  }

  function accountView() {
    return '<div class="account-layout"><div class="panel profile-card"><div class="profile-avatar">' + account.name.split(" ").map(function (x) { return x[0]; }).slice(0, 2).join("").toUpperCase() + '</div><h2>' + account.name + '</h2><p>' + account.role + '</p><span class="profile-status"><i></i> Conta ativa</span><div class="profile-meta"><span>MEMBRO DESDE</span><strong>Setembro de 2024</strong></div></div>' +
      '<form class="panel account-form" id="accountForm"><div class="panel-header"><div><h3>Dados da conta</h3><p>Atualize suas informações pessoais de acesso.</p></div><button class="primary" type="submit">Salvar perfil</button></div><div class="form-row"><label>Nome completo<input name="name" value="' + account.name + '" required></label><label>Função<select name="role"><option' + (account.role === "Administrador" ? " selected" : "") + '>Administrador</option><option' + (account.role === "Gerente" ? " selected" : "") + '>Gerente</option><option' + (account.role === "Operador" ? " selected" : "") + '>Operador</option></select></label></div><label>E-mail<input name="email" type="email" value="' + account.email + '" required></label><div class="password-block"><span class="settings-label">Segurança</span><p>Para trocar a senha, preencha os dois campos abaixo. Deixe em branco para manter a senha atual.</p><div class="form-row"><label>Nova senha<input name="password" type="password" minlength="6" placeholder="••••••••"></label><label>Confirmar nova senha<input name="passwordConfirm" type="password" minlength="6" placeholder="••••••••"></label></div></div></form></div>';
  }

  function overview() {
    return '<div class="metrics">' + metric("Vendas de hoje", "R$ 1.847,90", "+12,5%", "comparado a ontem", "cart", "blue") + metric("Saldo em caixa", "R$ 2.430,50", "+8,2%", "desde a abertura", "wallet", "green") +
      metric("Itens em estoque", "642", "-4,1%", "nos últimos 7 dias", "box", "violet", true) + metric("Estoque baixo", "5 itens", "", "2 precisam de atenção", "alert", "orange", false, true) + "</div>" +
      '<div class="dashboard-grid"><div class="panel chart-panel">' + panelHead("Desempenho de vendas", "Receita nos últimos 7 dias", "Últimos 7 dias") + chart() + "</div>" +
      '<div class="panel channels-panel">' + panelHead("Vendas por canal", "Distribuição desta semana") + '<div class="donut-wrap"><div class="donut"><div><strong>R$ 8,4k</strong><span>Total</span></div></div><div class="legend">' +
      legend("#315bea", "Loja física", "52%") + legend("#16a394", "Mercado Livre", "28%") + legend("#f49b45", "Shopee", "20%") + "</div></div></div></div>" +
      '<div class="bottom-grid"><div class="panel sales-panel">' + panelHead("Vendas recentes", "Últimas operações registradas", "Ver todas") + '<div class="sale-list">' +
      sales.map(function (s) { return '<div class="sale-row"><span class="time">' + s.time + '</span><span class="sale-icon">' + ic("cart", 17) + '</span><div class="sale-info"><strong>' + s.item + "</strong><span>" + s.channel + " · " + s.method + "</span></div><strong>" + money(s.value) + '</strong><span class="completed">' + ic("check", 12) + " Concluída</span></div>"; }).join("") + "</div></div>" +
      '<div class="panel cash-panel">' + panelHead("Caixa de hoje", "Aberto às 08:02") + '<div class="cash-status"><span><i></i> Caixa aberto</span><small>Operador: André</small></div>' +
      '<div class="cash-line"><span>Saldo inicial</span><strong>R$ 500,00</strong></div><div class="cash-line"><span>Entradas</span><strong class="positive">+ R$ 1.847,90</strong></div><div class="cash-line"><span>Saídas</span><strong class="negative">− R$ 82,40</strong></div>' +
      '<div class="cash-total"><span>Saldo esperado</span><strong>R$ 2.265,50</strong></div><button class="close-cash" data-a="cash">Realizar fechamento de caixa</button></div></div>';
  }

  function modal() {
    if (S.modal === "sale") {
      var opts = products.map(function (p) { return "<option" + (p.name === S.prod ? " selected" : "") + ">" + p.name + "</option>"; }).join("") + "<option" + (S.prod === "Impressão colorida" ? " selected" : "") + ">Impressão colorida</option>";
      return '<div class="modal-backdrop" data-bd><form class="modal" id="saleForm"><div class="modal-head"><div><span class="eyebrow">NOVA OPERAÇÃO</span><h2>Registrar venda</h2></div><button type="button" data-a="close">' + ic("x") + "</button></div>" +
        '<label>Produto ou serviço<select id="sp">' + opts + '</select></label><div class="form-row"><label>Quantidade<input id="sq" type="number" min="1" value="' + S.qty + '"></label><label>Canal<select><option>Loja física</option><option>Mercado Livre</option><option>Shopee</option></select></label></div>' +
        '<label>Forma de pagamento<select><option>Pix</option><option>Dinheiro</option><option>Cartão de débito</option><option>Cartão de crédito</option></select></label>' +
        '<div class="sale-summary"><span>Total da venda</span><strong id="st">' + total() + '</strong></div><button class="primary modal-submit" type="submit">Confirmar venda ' + ic("check", 18) + "</button></form></div>";
    }
    if (S.modal === "cash") {
      return '<div class="modal-backdrop" data-bd><form class="modal" id="cashForm"><div class="modal-head"><div><span class="eyebrow">CONFERÊNCIA DIÁRIA</span><h2>Fechamento de caixa</h2></div><button type="button" data-a="close">' + ic("x") + "</button></div>" +
        '<div class="close-summary"><div><span>Saldo esperado</span><strong>R$ 2.265,50</strong></div>' + ic("wallet", 28) + '</div><label>Valor contado em caixa<input name="counted" placeholder="R$ 2.265,50" required></label><label>Observações<textarea name="notes" placeholder="Registre qualquer diferença ou ocorrência do dia..."></textarea></label>' +
        '<button class="primary modal-submit" type="submit">Conferir e fechar caixa ' + ic("check", 18) + "</button></form></div>";
    }
    if (S.modal === "product") return '<div class="modal-backdrop" data-bd><form class="modal" id="productForm"><div class="modal-head"><div><span class="eyebrow">CATÁLOGO</span><h2>Adicionar produto</h2></div><button type="button" data-a="close">' + ic("x") + '</button></div><label>Nome do produto<input name="name" required placeholder="Ex.: Mouse sem fio"></label><div class="form-row"><label>SKU<input name="sku" required placeholder="ACE-0123"></label><label>Categoria<input name="category" required placeholder="Acessórios"></label></div><div class="form-row"><label>Estoque inicial<input name="stock" type="number" min="0" value="0" required></label><label>Estoque mínimo<input name="minimum" type="number" min="0" value="5" required></label></div><label>Preço de venda<input name="price" placeholder="R$ 0,00" required></label><button class="primary modal-submit" type="submit">Adicionar ao catálogo ' + ic("check", 18) + '</button></form></div>';
    if (S.modal === "move") { var target = products.filter(function (p) { return p.name === S.target; })[0]; return '<div class="modal-backdrop" data-bd><form class="modal" id="moveForm"><div class="modal-head"><div><span class="eyebrow">ESTOQUE</span><h2>Movimentar produto</h2></div><button type="button" data-a="close">' + ic("x") + '</button></div><p class="modal-description"><strong>' + (target ? target.name : '') + '</strong><br>Estoque atual: ' + (target ? target.stock : 0) + ' unidades</p><label>Tipo de movimentação<select name="type"><option value="in">Entrada</option><option value="out">Saída</option></select></label><label>Quantidade<input name="quantity" type="number" min="1" value="1" required></label><button class="primary modal-submit" type="submit">Confirmar movimentação ' + ic("check", 18) + '</button></form></div>'; }
    return "";
  }
  function total() {
    var p = products.filter(function (x) { return x.name === S.prod; })[0];
    return money((p ? p.price : 12) * (S.qty || 0));
  }

  function render() {
    var a = S.active;
    var body = a === "Visão geral" ? overview() : a === "Estoque" ? inventory() : a === "Caixa" ? cashView() : a === "Configurações" ? settingsView() : a === "Conta" ? accountView() : soon();
    root.innerHTML = '<div class="app-shell' + (settings.compact ? ' compact' : '') + '"><aside class="sidebar ' + (S.menu ? "sidebar-open" : "") + '"><div class="brand"><div class="brand-mark"><span>Z</span></div><div><strong>Zick</strong><b>Gestão</b></div></div><div class="nav-label">MENU PRINCIPAL</div><nav>' +
      nav.map(function (n) { return '<button class="' + (a === n[0] ? "active" : "") + '" data-a="nav" data-n="' + n[0] + '">' + ic(n[1]) + "<span>" + n[0] + "</span>" + (n[0] === "Estoque" ? "<small>2</small>" : "") + "</button>"; }).join("") + "</nav>" +
      '<div class="sidebar-bottom"><button class="' + (a === "Configurações" ? "active" : "") + '" data-a="settings"><span class="nav-icon">' + ic("settings") + '</span><span>Configurações</span></button><div class="help-card"><span>ZG</span><strong>Precisa de ajuda?</strong><p>Acesse o guia rápido do sistema.</p><button data-a="guide">Ver guia</button></div>' +
      '<button class="user" data-a="account"><div class="avatar">' + account.name.split(" ").map(function (x) { return x[0]; }).slice(0, 2).join("").toUpperCase() + '</div><div><strong>' + account.name + '</strong><span>' + account.role + '</span></div>' + ic("chevron", 16) + "</button></div></aside>" +
      (S.menu ? '<div class="scrim" data-a="menu"></div>' : "") +
      '<main><header><button class="mobile-menu" data-a="menu" aria-label="Abrir menu">' + ic("menu") + '</button><div class="global-search">' + ic("search", 18) + '<input id="globalSearch" placeholder="Buscar no sistema..."><kbd>⌘ K</kbd></div>' +
      '<div class="header-actions">' + (settings.notifications ? '<button class="icon-button" data-a="notification" aria-label="Notificações">' + ic("bell") + '<i></i></button>' : '') + '<button class="header-user" data-a="account"><div class="avatar">' + account.name.split(" ").map(function (x) { return x[0]; }).slice(0, 2).join("").toUpperCase() + '</div><span>' + account.name.split(" ")[0] + '</span>' + ic("chevron", 14) + "</button></div></header>" +
      '<section class="content"><div class="page-heading"><div><span class="eyebrow">PAINEL DE CONTROLE</span><h1>' + a + "</h1><p>Acompanhe o desempenho da sua empresa em tempo real.</p></div>" +
      '<div class="heading-actions"><button class="secondary" data-a="export">' + ic("download", 17) + ' Exportar</button><button class="primary" data-a="sale">' + ic("plus", 18) + " Nova venda</button></div></div>" + body + "</section></main>" + modal() + "</div>";
  }

  document.addEventListener("click", function (e) {
    var bd = e.target.closest("[data-bd]");
    if (bd && e.target === bd) { S.modal = null; render(); return; }
    var el = e.target.closest("[data-a]");
    if (!el) return;
    var a = el.getAttribute("data-a");
    if (a === "nav") { S.active = el.getAttribute("data-n"); S.menu = false; render(); window.scrollTo(0, 0); }
    else if (a === "settings") { S.active = "Configurações"; S.menu = false; render(); window.scrollTo(0, 0); }
    else if (a === "account") { S.active = "Conta"; S.menu = false; render(); window.scrollTo(0, 0); }
    else if (a === "menu") { S.menu = !S.menu; render(); }
    else if (a === "sale") { S.modal = "sale"; render(); }
    else if (a === "cash") { S.modal = "cash"; render(); }
    else if (a === "open-cash") { S.cashOpen = true; render(); toast("Caixa aberto com sucesso."); }
    else if (a === "addprod") { S.modal = "product"; render(); }
    else if (a === "move") { S.target = el.getAttribute("data-n"); S.modal = "move"; render(); }
    else if (a === "notification") { toast("Você não tem novas notificações."); }
    else if (a === "panel") { var panel = el.getAttribute("data-panel"); toast(panel === "all-sales" ? "Exibindo todas as vendas registradas." : panel === "statement" ? "Extrato completo disponível nesta visão." : "Período de 7 dias selecionado."); }
    else if (a === "close") { S.modal = null; render(); }
    else if (a === "export" || a === "export2") { downloadCsv("zick-gestao-relatorio.csv", [["Produto", "SKU", "Categoria", "Estoque", "Preço", "Status"]].concat(products.map(function (p) { return [p.name, p.sku, p.category, p.stock, money(p.price), p.status]; }))); toast("Relatório preparado para download."); }
    else if (a === "guide") toast("Guia rápido: use Estoque para cadastrar produtos, Vendas para registrar operações e Caixa para conferir o saldo.");
  });
  document.addEventListener("input", function (e) {
    if (e.target.id === "globalSearch" && e.target.value.trim()) { var term = e.target.value.trim().toLowerCase(); var match = nav.filter(function (n) { return n[0].toLowerCase().includes(term); })[0]; if (match) { S.active = match[0]; render(); } }
    if (e.target.id === "q") { S.query = e.target.value; document.getElementById("tbody").innerHTML = rows(); }
    else if (e.target.id === "sq") { S.qty = Number(e.target.value); document.getElementById("st").textContent = total(); }
  });
  document.addEventListener("change", function (e) {
    if (e.target.id === "sp") { S.prod = e.target.value; document.getElementById("st").textContent = total(); }
    if (e.target.id === "categoryFilter") { S.category = e.target.value; render(); }
  });
  document.addEventListener("submit", function (e) {
    if (e.target.id === "saleForm") { e.preventDefault(); var sold = products.filter(function (p) { return p.name === S.prod; })[0], quantity = Math.max(1, Number(S.qty) || 1); if (sold && sold.stock < quantity) { toast("Estoque insuficiente para esta venda."); return; } if (sold) { sold.stock -= quantity; updateStatus(sold); } sales.unshift({ time: new Date().toLocaleTimeString("pt-BR", { hour: "2-digit", minute: "2-digit" }), item: S.prod, channel: "Loja física", value: (sold ? sold.price : 12) * quantity, method: "Pix" }); persist(); S.modal = null; render(); toast("Venda registrada e estoque atualizado."); }
    if (e.target.id === "settingsForm") {
      e.preventDefault();
      var f = new FormData(e.target);
      settings.company = f.get("company"); settings.email = f.get("email"); settings.currency = f.get("currency");
      settings.notifications = f.get("notifications") === "on"; settings.lowStock = f.get("lowStock") === "on"; settings.compact = f.get("compact") === "on";
      persist(); render(); toast("Configurações salvas com sucesso.");
    }
    if (e.target.id === "cashForm") { e.preventDefault(); var counted = parseMoney(new FormData(e.target).get("counted")), expected = 2265.50; S.cashOpen = false; persist(); S.modal = null; render(); toast(Math.abs(counted - expected) < 0.01 ? "Caixa fechado sem divergências." : "Caixa fechado com divergência de " + money(counted - expected) + "."); }
    if (e.target.id === "productForm") { e.preventDefault(); var f = new FormData(e.target), product = { name: f.get("name"), sku: f.get("sku"), category: f.get("category"), stock: Number(f.get("stock")), minimum: Number(f.get("minimum")), price: parseMoney(f.get("price")), status: "Normal" }; updateStatus(product); products.push(product); persist(); S.modal = null; S.active = "Estoque"; render(); toast("Produto adicionado ao catálogo."); }
    if (e.target.id === "moveForm") { e.preventDefault(); var mf = new FormData(e.target), target = products.filter(function (p) { return p.name === S.target; })[0], amount = Math.max(1, Number(mf.get("quantity")) || 1); if (target && mf.get("type") === "out" && target.stock < amount) { toast("A saída não pode ser maior que o estoque atual."); return; } if (target) { target.stock += mf.get("type") === "in" ? amount : -amount; updateStatus(target); } persist(); S.modal = null; render(); toast("Movimentação registrada."); }
    if (e.target.id === "accountForm") {
      e.preventDefault();
      var f = new FormData(e.target), password = f.get("password"), confirmation = f.get("passwordConfirm");
      if (password && password !== confirmation) { toast("As senhas não conferem."); return; }
      if (password && password.length < 6) { toast("A nova senha precisa ter pelo menos 6 caracteres."); return; }
      account.name = f.get("name"); account.email = f.get("email"); account.role = f.get("role");
      persist(); render(); toast("Perfil atualizado com sucesso.");
    }
  });
  document.addEventListener("keydown", function (e) {
    if ((e.metaKey || e.ctrlKey) && e.key.toLowerCase() === "k") { e.preventDefault(); var search = document.getElementById("globalSearch"); if (search) search.focus(); }
    if (e.key === "Escape" && (S.modal || S.menu)) { S.modal = null; S.menu = false; render(); }
  });
  render();
})();
